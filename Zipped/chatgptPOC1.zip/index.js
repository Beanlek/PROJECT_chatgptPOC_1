const express = require("express");
require("dotenv").config();

const app = express();
app.use(express.json());

//Old
// const { Configuration, OpenAIApi } = require("openai");

// const configuration = new Configuration({
//     apiKey: process.env.OPEN_API_KEY,
// });
// const openai = new OpenAIApi(configuration);

//New
const OpenAI = require("openai");

const openai = new OpenAI({
  apiKey: process.env.OPEN_AI_KEY
});

app.post("/find-complexity", async (req, res) => {
    try {
        const response = await openai.completions.create({
            model: "text-curie-001",
            prompt: `
                const example = (arr) => {
                    arr.map((item) => {
                        console.log(item2);
                    });
                };

                The time commplexity of this function is
                ###
            `,

            max_tokens: 64,
            temperature: 0,
            stop: ["\n"],
        });

        return res.status(200).json({
            success: true,
            data: response.choices[0].text,
            message: "Working.",
        });
    } catch (error) {
        
        return res.status(400).json({
            success: false,
            error: error instanceof OpenAI.APIError
                ? error.message
                : "There was an issue on the server."
        })
    }
});

const port = process.env.PORT || 5000;

app.listen(port, () => console.log('Server listening on port ${port}'));